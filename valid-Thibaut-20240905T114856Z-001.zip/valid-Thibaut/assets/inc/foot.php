</main>
        <footer class="bg-dark d-flex justify-content-center text-center text-white">
      
            <div class="text-center p-3">
                Bonne Validation!
            </div>
        </footer>

       
    <script>
      const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
      const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
    </script>
   
    </body>
</html>